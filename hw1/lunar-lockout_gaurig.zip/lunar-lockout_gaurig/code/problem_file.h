#include <iostream>
#include <queue>
#include <set>
#include <list>
#include <map>
#include <vector>
#include <math.h>

typedef std::vector<int> state;

struct node
{
	state st;
	node *parent;/* data */
};

std::queue<node*> open_list;
std::set<state> closed_list;
std::list<node*> successors;
std::list<state> path;
bool found_goal;

std::list<state> bfs(node*, node*, int);
std::list<node*> get_successors(node*);
std::list<node*> find_feasible_neighbors(node*);
int locationToId(int, int, int);

