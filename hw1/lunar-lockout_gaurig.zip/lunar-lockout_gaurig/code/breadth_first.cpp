#include "problem_file.h"

using namespace std;

std::list<state> bfs(node* start_node, node* goal_node, int board_dim)
{
	cout<<"starting plan"<<endl;
	found_goal = 0;
	node* item = NULL;
	node* last_node = NULL;
	open_list.push(start_node);
	int total_states = 0;
	while (!open_list.empty())
	{
		item = open_list.front();
		open_list.pop();
		total_states = total_states + 1;
		if (closed_list.find(item->st) == closed_list.end())
		{
			for (int i = 0 ; i < item->st.size(); i++)
			//cout<<" new extended state "<<item->st[i];
			//cout<<endl;
			closed_list.insert(item->st);
			successors = get_successors(item);
			for (std::list<node*>::iterator itr = successors.begin(); itr != successors.end(); itr ++)
			{
				node* temp = *itr;
				temp->parent = item;
				if (temp->st[0] == goal_node->st[0])
					{
						last_node = temp;
						found_goal = 1;
						cout<<"found goal"<<endl;
						break;						
					}
				else
					if (closed_list.find(temp->st) == closed_list.end())
						open_list.push(*itr);			
						//cout<<"pushed successor to open list"<<endl; 	
			}			
		}
		if (found_goal)
			break;	
	}
	cout<<"making final plan"<<endl;
	while (last_node && last_node->st != start_node->st)
	{
		if (last_node->st == goal_node->st)
			path.push_front(goal_node->st);
		else
			path.push_front(last_node->st);
		if (last_node->parent != NULL)
			last_node = last_node->parent;
	}
	cout<<"returning plan"<<endl;
	cout<<"Total states explored "<<total_states<<endl;
	path.push_front(start_node->st);
	int num_steps = 0;
	for (std::list<state>::iterator itr = path.begin(); itr != path.end(); itr ++)
	{
		state next_state = *itr;
		num_steps = num_steps + 1;
		cout<<"t = "<<num_steps;
		for (int i = 0; i < next_state.size(); i++)
		{
			int spaceship_location = next_state[i];
			int grid_coordinates[2] = {floor(spaceship_location%board_dim), (spaceship_location/board_dim)};
			cout<<"  spaceship "<<i<<" at ("<<grid_coordinates[0]<<","<<grid_coordinates[1]<<")";
			
		}
		cout<<endl;
	}
	return path;
}

std::list<node*> get_successors(node* item)
{
	std::list<node*> neighbor_states;
	neighbor_states = find_feasible_neighbors(item);
	return neighbor_states;
}

int locationToId(int board_dim, int x, int y)
{
	return ((y*board_dim) + x);
}


int main()
{
	cout<<"initializing"<<endl;
	cout<<"spaceship 0 : red, spaceship 1 : yellow, spaceship 2 : orange, spaceship 3 : purple, spaceship 4 : green spaceship 5: blue"<<endl;
	int dim_board = 5;
	int start_array_9[] = {locationToId(dim_board,4,2),locationToId(dim_board,0,3),locationToId(dim_board,4,4),locationToId(dim_board,1,1),locationToId(dim_board,2,2)};
	int start_array_18[] = {locationToId(dim_board,4,2),locationToId(dim_board,0,0),locationToId(dim_board,0,4),locationToId(dim_board,0,2)};
	int start_array_27[] = {locationToId(dim_board,0,4),locationToId(dim_board,2,3),locationToId(dim_board,4,1),locationToId(dim_board,2,0),locationToId(dim_board,4,4), locationToId(dim_board,0,0)};
	int start_array_36[] = {locationToId(dim_board,4,2),locationToId(dim_board,1,4),locationToId(dim_board,3,0),locationToId(dim_board,1,0),locationToId(dim_board,3,4), locationToId(dim_board,0,2)};
	
	//int start_array[] = {locationToId(dim_board,4,2),locationToId(dim_board,0,3),locationToId(dim_board,4,4),locationToId(dim_board,1,1),locationToId(dim_board,2,2)};;

	/*uncomment this general section to solve any problem with state that can be changed in state_array[] above
	node* start = new node;
	node* goal = new node;
	int start_len = sizeof(start_array)/sizeof(start_array[0]);
    start->st.insert(start->st.begin(), start_array, start_array + start_len);
	start->parent = NULL;
	int goal_array [] = {locationToId(dim_board,2,2)};
	int goal_len = sizeof(goal_array)/sizeof(goal_array[0]);
    goal->st.insert(goal->st.begin(), goal_array, goal_array + goal_len);
	goal->parent = NULL;
	bfs(start,goal, dim_board);*/

	/*cout<<"solving problem 9"<<endl;
	node* start_9 = new node;
	node* goal_9 = new node;
	int start_len_9 = sizeof(start_array_9)/sizeof(start_array_9[0]);
    start_9->st.insert(start_9->st.begin(), start_array_9, start_array_9 + start_len_9);
	start_9->parent = NULL;
	int goal_array_9 [] = {locationToId(dim_board,2,2)};
	int goal_len_9 = sizeof(goal_array_9)/sizeof(goal_array_9[0]);
    goal_9->st.insert(goal_9->st.begin(), goal_array_9, goal_array_9 + goal_len_9);
	goal_9->parent = NULL;
	bfs(start_9,goal_9, dim_board);*/

	/*cout<<"solving problem 18"<<endl;
	node* start_18 = new node;
	node* goal_18 = new node;	
	int start_len_18 = sizeof(start_array_18)/sizeof(start_array_18[0]);
    start_18->st.insert(start_18->st.begin(), start_array_18, start_array_18 + start_len_18);
	start_18->parent = NULL;
	int goal_array_18 [] = {locationToId(dim_board,2,2)};
	int goal_len_18 = sizeof(goal_array_18)/sizeof(goal_array_18[0]);
    goal_18->st.insert(goal_18->st.begin(), goal_array_18, goal_array_18 + goal_len_18);
	goal_18->parent = NULL;
	bfs(start_18,goal_18, dim_board);*/

	/*cout<<"solving problem 27"<<endl;
	node* start_27 = new node;
	node* goal_27 = new node;	
	int start_len_27 = sizeof(start_array_27)/sizeof(start_array_27[0]);
    start_27->st.insert(start_27->st.begin(), start_array_27, start_array_27 + start_len_27);
	start_27->parent = NULL;
	int goal_array_27 [] = {locationToId(dim_board,2,2)};
	int goal_len_27 = sizeof(goal_array_27)/sizeof(goal_array_27[0]);
    goal_27->st.insert(goal_27->st.begin(), goal_array_27, goal_array_27 + goal_len_27);
	goal_27->parent = NULL;
	bfs(start_27,goal_27, dim_board);*/

	cout<<"solving problem 36"<<endl;
	node* start_36 = new node;
	node* goal_36 = new node;	
	int start_len_36 = sizeof(start_array_36)/sizeof(start_array_36[0]);
    start_36->st.insert(start_36->st.begin(), start_array_36, start_array_36 + start_len_36);
	start_36->parent = NULL;
	int goal_array_36 [] = {locationToId(dim_board,2,2)};
	int goal_len_36 = sizeof(goal_array_36)/sizeof(goal_array_36[0]);
    goal_36->st.insert(goal_36->st.begin(), goal_array_36, goal_array_36 + goal_len_36);
	goal_36->parent = NULL;
	bfs(start_36,goal_36, dim_board);
}

