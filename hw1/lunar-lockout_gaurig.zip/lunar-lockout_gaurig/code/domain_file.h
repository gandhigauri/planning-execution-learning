#include <iostream>
#include <queue>
#include <set>
#include <list>
#include <map>
#include <vector>
#include <math.h>
#include <algorithm>

typedef std::vector<int> state;
typedef int location;
typedef char object;
typedef char direction;

struct node
{
	state st;
	node *parent;/* data */
};

/*objects*/
object spaceships[] = {'r', 'y', 'o', 'p', 'g', 'b'};
direction directions[] = {'l', 'r', 'u', 'd'};
int total_objects, total_directions;
int board_dim =5;

/*predicates*/
bool At(object, location, state);
bool CanMove(object, direction, state);
bool IsEmpty(location, state);
bool InBoard(location, int);

/*actions*/
state Move(object, direction, state);

int* IdToLocation(location, int);
int locationToId(int, int, int);

